#include <conio.h>
#include <stdio.h>

main()
{
	char nama[20];
	char npm [20];
	char jurusan[20];
	char kelas[1];

	
	char x='y';
	while (x='y'){
	
	printf("Masukkan Nama Anda       :");
	gets(nama);
	fflush(stdin);
	
	printf("Masukkan NPM Anda        :");
	gets(nama);
	fflush(stdin);
	
	printf("Masukkan Jurusan Anda    :");
	gets(nama);
	fflush(stdin);
	
	printf("Masukkan Kelas Anda      :");
	gets(nama);
	fflush(stdin);
	

	
    }
    
    printf("\nData Diri Mahasiswa Fakultas Ilmu Komputer");
    printf("\n==========================================");
    printf("Masukkan Nama Anda       :");
    printf("Masukkan NPM Anda        :");
    printf("Masukkan Jurusan Anda    :");
    printf("Masukkan Kelas Anda      :");
    
    
    printf("\nMemasukkan data lagi? (y/n)");
    scanf("%c", x);
    fflush(stdin);
    
}
